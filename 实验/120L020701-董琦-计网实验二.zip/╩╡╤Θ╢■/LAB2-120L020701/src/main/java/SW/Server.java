package SW;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Server {
    private byte serial;
    private final int mss=1496;
    private DatagramSocket socket;
    private int size=2;
    public Server(int port) throws SocketException {
        this.socket=new DatagramSocket(port);
        this.serial=0;
    }
    public void run(){
        System.out.println("SW server start.");
        while(true){
            byte[] buf=new byte[mss+4];
            DatagramPacket packet=new DatagramPacket(buf,mss+4);
            try {
                this.socket.receive(packet);
                switch (new String(buf, 0, packet.getLength())) {
                    case "-time":
                        Date date = new Date();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
                        byte[] time = dateFormat.format(date).getBytes(StandardCharsets.UTF_8);
                        DatagramPacket recall = new DatagramPacket(time, time.length, packet.getAddress(), packet.getPort());
                        this.socket.send(recall);
                        break;
                    case "-quit":
                        byte[] bye = "Good bye!".getBytes();
                        this.socket.send(new DatagramPacket(bye, bye.length, packet.getAddress(), packet.getPort()));
                        break;
                    case "-testsw":
                        String filename = "src\\main\\resources\\swTest.txt";
                        send(filename, packet.getAddress(), packet.getPort());
                        break;
                    default:
                        socket.send(packet);
                        break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void send(String filename,InetAddress targetHost,int targetPort) throws SocketException, FileNotFoundException {
        File file=new File(filename);
        this.socket.connect(new InetSocketAddress(targetHost,targetPort));

        byte[] sendBuf=new byte[mss+4];
        byte[] recvBuf=new byte[mss+4];
        DatagramPacket send=new DatagramPacket(sendBuf,mss+4);
        DatagramPacket recv=new DatagramPacket(recvBuf,mss+4);
        this.socket.setSoTimeout(1000);

        if(!file.exists())
        {
            throw new FileNotFoundException(filename+" Not Found!");
        }

        boolean ack=true;

        try(FileInputStream reader=new FileInputStream(file)) {
            do {
                int length = 0;
                if (ack) {
                    sendBuf[0] = this.serial;
                    length = reader.read(sendBuf, 4, mss);
                    if (length == -1) {
                        break;
                    }
                    sendBuf[2] = (byte) (length & 0xFF);
                    sendBuf[3] = (byte) (length >> 8  & 0xFF);
                    //模拟发出后未收到，方法是不发送
                    if(Math.random()>0.1)
                        this.socket.send(send);
                }
                try {
                    this.socket.receive(recv);
                    if (recv.getData()[1] == this.serial) {
                        updateSerial();
                        ack = true;
                    } else {
                        System.out.println("检测冗余,不做反应。");
                        ack = false;
                    }
                } catch (SocketTimeoutException e) {
                    System.out.println("超时，重新发送分组。");
                    ack = false;
                    if(Math.random()>0.1)
                        this.socket.send(send);
                    else
                        System.out.println("发送的包丢失。");
                }
            } while (true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.socket.setSoTimeout(0);
    }
    private void updateSerial(){
        this.serial++;
        if(this.serial==this.size)
            this.serial=0;
    }
    public static void main(String[] args) throws SocketException {
        Server server =new Server(7759);
        server.run();
    }
}
