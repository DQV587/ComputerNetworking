package SW;

import com.sun.xml.internal.ws.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class Client {
    private byte serial;
    private final int mss=1496;
    private DatagramSocket socket;
    private final int size=2;
    public Client(int port) throws SocketException {
        this.socket=new DatagramSocket(port);
        this.serial=0;
    }
    public void qTime(){
        String message="-time";
        byte[] buf=new byte[mss+4];
        message.getBytes(0,message.length(),buf,0);
        DatagramPacket packet=new DatagramPacket(buf, message.length());
        try {
            this.socket.connect(new InetSocketAddress("127.0.0.1",7759));
            this.socket.send(packet);
            DatagramPacket recv=new DatagramPacket(buf,mss+4);
            this.socket.receive(recv);
            System.out.write(buf,0,recv.getLength());
            System.out.println();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void qQuit(){
        String message="-quit";
        byte[] buf=new byte[mss+4];
        message.getBytes(0,message.length(),buf,0);
        DatagramPacket packet=new DatagramPacket(buf, message.length());
        try {
            this.socket.connect(new InetSocketAddress("127.0.0.1",7759));
            this.socket.send(packet);
            DatagramPacket recv=new DatagramPacket(buf,mss+4);
            this.socket.receive(recv);
            System.out.write(buf,0,recv.getLength());
            System.out.println();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void qTest(){
        String message="-testsw";
        byte[] buf=new byte[mss+4];
        message.getBytes(0,message.length(),buf,0);
        DatagramPacket packet=new DatagramPacket(buf, message.length());

        String recFilename="src\\main\\resources\\swResult.txt";
        File recFile=new File(recFilename);
        if(!recFile.exists()){
            try {
                recFile.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        try(FileOutputStream out=new FileOutputStream(recFile)) {
            this.socket.connect(new InetSocketAddress("127.0.0.1", 7759));
            DatagramPacket send=new DatagramPacket(buf,mss+4);
            DatagramPacket recv= new DatagramPacket(buf, mss + 4);;

            int length = 0;
            int count=0;

            this.socket.send(packet);
            do {
                //模拟延时收到，方法是延迟接收
                if(Math.random()<0.1)
                    Thread.sleep(1000);
                this.socket.receive(recv);
                buf[1] = recv.getData()[0];
                if (recv.getData()[0] == this.serial) {
                    System.out.println("收到正确的分组。");
                    count++;
                    //收到正确分组，更新序号，保存数据
                    updateSerial();

                    length = recv.getData()[2]& 0xFF;
                    length |= recv.getData()[3] << 8;

                    out.write(buf, 4, length);
                }else{
                    System.out.println("收到冗余分组。");
                }
                //模拟返回包丢失，方法是不发送
                if(Math.random()>0.1){
                    this.socket.send(packet);
                }else{
                    System.out.println("返回的包丢失");
                }
            } while (length == mss);
            System.out.println("共收到："+count+"个包");
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    private void updateSerial(){
        this.serial++;
        if(this.serial==this.size)
            this.serial=0;
    }
    public static void main(String[] args) throws SocketException {
        Client client=new Client(7760);
        client.qTime();
        client.qQuit();
        client.qTest();

    }
}
