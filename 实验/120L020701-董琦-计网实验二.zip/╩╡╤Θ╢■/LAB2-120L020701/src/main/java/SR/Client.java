package SR;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Client {
    private final int mss=1496;
    private final DatagramSocket socket;
    private byte base;
    private final byte size=8;
    private Map<Byte,DatagramPacket> recvBufs;
    private Set<Byte> Received;
    public Client(int port) throws SocketException {
        this.socket=new DatagramSocket(port);
    }
    public void qTime(){
        String message="-time";
        byte[] buf=new byte[mss+4];
        message.getBytes(0,message.length(),buf,0);
        DatagramPacket packet=new DatagramPacket(buf, message.length());
        try {
            this.socket.connect(new InetSocketAddress("127.0.0.1",7749));
            this.socket.send(packet);
            DatagramPacket recv=new DatagramPacket(buf,mss+4);
            this.socket.receive(recv);
            System.out.write(buf,0,recv.getLength());
            System.out.println();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void qQuit(){
        String message="-quit";
        byte[] buf=new byte[mss+4];
        System.out.println(message);
        message.getBytes(0,message.length(),buf,0);
        DatagramPacket packet=new DatagramPacket(buf, message.length());
        try {
            this.socket.connect(new InetSocketAddress("127.0.0.1",7749));
            this.socket.send(packet);
            DatagramPacket recv=new DatagramPacket(buf,mss+4);
            this.socket.receive(recv);
            System.out.write(buf,0,recv.getLength());
            System.out.println();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void qTest(){
        initialize();
        String message="-testgnb";
        String recFilename="src\\main\\resources\\SR_ClientResult.txt";
        String sendFilename="src\\main\\resources\\SR_ServerTest.txt";
        File recFile=new File(recFilename);
        File sendFile=new File(sendFilename);

        byte[] sendBuf=new byte[mss+4];
        message.getBytes(0,message.length(),sendBuf,0);
        DatagramPacket sendPacket=new DatagramPacket(sendBuf,message.length());
        if(!recFile.exists()){
            try {
                recFile.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        try(FileOutputStream writer=new FileOutputStream(recFile);
            FileInputStream reader=new FileInputStream(sendFile)
        ) {
            this.socket.connect(new InetSocketAddress("127.0.0.1", 7749));

            byte myserial = 0;
            int length;
            int count=0;
            int myLength;

            this.socket.send(sendPacket);
            do {
                //模拟延时收到，方法是延迟接收
                if(Math.random()<0.05) {
                    System.out.println("网络发生延迟");
                    Thread.sleep(500);
                }

                byte[] recvBuf=new byte[mss+4];
                DatagramPacket recvPacket= new DatagramPacket(recvBuf, mss + 4);;
                this.socket.receive(recvPacket);

                byte received=recvPacket.getData()[0];
                if (received>=base&&received<base+size) {
                    System.out.println("收到正确的分组:"+ received+"  期望分组："+recvPacket.getData()[1]);
                    recvBufs.put(received,recvPacket);
                    if(received==base){
                        while(recvBufs.containsKey(base)){
                            DatagramPacket packet=recvBufs.get(base);
                            length = packet.getData()[2]& 0xFF;
                            length |= packet.getData()[3] << 8;
                            writer.write(packet.getData(), 4, length);
                            System.out.println("写入分组："+base);
                            recvBufs.remove(received);
                            base++;
                            count++;
                        }
                    }
                }else if(received==-1){
                    System.out.println("文件接收完毕，发送尚未完成。期望分组："+recvPacket.getData()[1]);
                }else if(received<base&&received>=base-size){
                    System.out.println("收到冗余分组:"+recvPacket.getData()[0]);
                }

                if(received ==-1&&recvPacket.getData()[1]==-1)
                    break;

                //构建发送报文
                sendPacket=new DatagramPacket(sendBuf,mss+4);
                if(myserial !=-1&&recvPacket.getData()[1]== myserial){
                    myLength=reader.read(sendBuf,4,mss);
                    System.out.println(myLength+":"+ myserial);
                    if(myLength==-1){
                        myserial =-1;
                        System.out.println("文件发送完毕");
                    }else
                        myserial++;
                    sendBuf[2] = (byte) (myLength & 0xFF);
                    sendBuf[3] = (byte) (myLength >> 8  & 0xFF);
                }
                sendBuf[0]= myserial;
                sendBuf[1]=received;

                //模拟返回包丢失，方法是不发送
                if(Math.random()>0.05){
                    System.out.println("成功发送ACK"+sendBuf[1]+"和分组"+myserial);
                    this.socket.send(sendPacket);
                }else{
                    System.out.println("返回的包丢失");
                }
            } while (true);

            System.out.println("共收到："+count+"个包");
            this.socket.disconnect();
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private void initialize() {
        this.base=0;
        recvBufs=new HashMap<>(8);
        this.Received =new HashSet<>(size);
    }

    public static void main(String[] args) throws SocketException {
        Client client=new Client(7750);
        client.qTime();
        client.qQuit();
        client.qTest();
    }
}
