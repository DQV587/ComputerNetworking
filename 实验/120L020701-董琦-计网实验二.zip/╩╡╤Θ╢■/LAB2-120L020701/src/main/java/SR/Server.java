package SR;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class Server {
    private byte mySerial;
    private byte serial;
    private final int mss=1496;
    private final byte size=8;
    private byte base;
    private Map<Byte,DatagramPacket> sendBufs;
    private DatagramSocket socket;
    private Map<Byte,Timer> timers;
    private Map<Byte,Boolean> timeUp;
    private Set<Byte> notReceived;
    private byte count;

    public Server(int port) throws SocketException {
        this.socket=new DatagramSocket(port);
    }
    public void run(){
        while(true){
            byte[] buf=new byte[mss+4];
            DatagramPacket packet=new DatagramPacket(buf,mss+4);
            try {
                this.socket.receive(packet);
                switch (new String(buf, 0, packet.getLength())) {
                    case "-time":
                        Date date = new Date();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
                        byte[] time = dateFormat.format(date).getBytes(StandardCharsets.UTF_8);
                        DatagramPacket recall = new DatagramPacket(time, time.length, packet.getAddress(), packet.getPort());
                        this.socket.send(recall);
                        break;
                    case "-quit":
                        byte[] bye = "Good bye!".getBytes();
                        this.socket.send(new DatagramPacket(bye, bye.length, packet.getAddress(), packet.getPort()));
                        break;
                    case "-testgnb":
                        String filename = "src\\main\\resources\\SR_ClientTest.txt";
                        sendFile(filename, packet.getAddress(), packet.getPort());
                        break;
                    default:
                        this.socket.send(packet);
                        break;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    private void initialize(){
        this.mySerial =0;
        this.serial=0;
        this.count=0;
        this.timers=new HashMap<>(size);
        this.sendBufs=new HashMap<>(size);
        this.timeUp=new HashMap<>(size);
        this.notReceived =new HashSet<>(size);
        for(int i=0;i<size;i++){
            sendBufs.put((byte) i,new DatagramPacket(new byte[mss+4],mss+4));
        }
        base=0;
    }

    public void sendFile(String filename, InetAddress targetHost, int targetPort) throws SocketException, FileNotFoundException {
        initialize();

        File sendFile=new File(filename);
        String recvFilemame="src\\main\\resources\\SR_ServerResult.txt";
        File recvFile=new File(recvFilemame);

        this.socket.connect(new InetSocketAddress(targetHost,targetPort));

        if(!sendFile.exists())
        {
            throw new FileNotFoundException(filename+" Not Found!");
        }

        boolean ack=true;
        try(FileInputStream reader=new FileInputStream(sendFile);
            FileOutputStream writer=new FileOutputStream(recvFile)
        ) {
            byte[] recvBuf=new byte[mss+4];
            DatagramPacket recv=new DatagramPacket(recvBuf,mss+4);
            this.socket.setSoTimeout(700);

            do {
                int myLength = 0;
                int length;
                if (ack&&mySerial!=-1) {
                    for(; mySerial <this.size; mySerial++){
                        byte number= (byte) (mySerial +base);
                        DatagramPacket sendPacket=this.sendBufs.get(number);
                        byte[] sendBuf=sendPacket.getData();
                        myLength = reader.read(sendBuf, 4, mss);
                        count++;
                        sendBuf[0] = number;
                        sendBuf[2] = (byte) (myLength & 0xFF);
                        sendBuf[3] = (byte) (myLength >> 8  & 0xFF);
                        //模拟发出后未收到，方法是不发送
                        send(sendPacket,number);

                        if (myLength<mss) {
                            break;
                        }
                    }
                    if (myLength<mss) {
                        mySerial=-1;
                        System.out.println(myLength+"更新序号为-1");
                    }
                }else if(this.sendBufs.isEmpty()){
                    byte[] sendBuf=new byte[mss+4];
                    DatagramPacket sendPacket=new DatagramPacket(sendBuf,mss+4);
                    sendBuf[0]=-1;
                    sendBuf[1]=serial;
                    System.out.println("文件发送完毕。"+" 期望分组："+(byte)(serial+(byte) 1));
                    this.socket.send(sendPacket);
                }

                try {
                    this.socket.receive(recv);
                }catch (SocketTimeoutException exception){
                    if(this.timeUp.containsValue(true)){
                        resend();
                    }
                }

                byte num=recv.getData()[1];
                System.out.println("接收分组序号"+num);
                if(notReceived.contains(num)){

                    System.out.println("notReceived:"+notReceived);

                    if(mySerial!=-1)
                        update(num);
                    else delete(num);

                    if (num == base) {
                        ack = true;
                        updateBase();
                        System.out.println(num+"分组成功确认接收. base滑动至："+base);
                    } else if(num>base&&num<base+size){
                        System.out.println(num+"分组成功确认接收.base不变："+base);
                        ack=false;
                    }
                }
                else if(num>=0) {
                    System.out.println(num+"冗余分组,不做反应。base不变："+this.base);
                    ack = false;
                }
                System.out.println(this.sendBufs);

                if(recv.getData()[0]==(byte)(serial+(byte) 1)){
                    System.out.println("收到分组"+(++serial));
                    length = recv.getData()[2]& 0xFF;
                    length |= recv.getData()[3] << 8;
                    writer.write(recvBuf,4,length);
                }else if(recv.getData()[0]==-1){
                    serial=-1;
                    System.out.println("收到全部文件");
                }
            } while (recvBuf[1]!=-1||serial!=-1);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        for(Map.Entry<Byte,Timer> entry:this.timers.entrySet()){
            entry.getValue().cancel();
        }

        System.out.println("传输文件结束");
        byte[] terminate=new byte[2];
        terminate[0]=(byte) -1;
        terminate[1]=(byte) -1;
        try {
            this.socket.send(new DatagramPacket(terminate,2));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.socket.disconnect();
        this.socket.setSoTimeout(0);
    }

    private void updateBase() {
        if(notReceived.isEmpty()){
            if(mySerial!=-1) {
                base += mySerial;
                mySerial = 0;
            }else {
                base= count;
                this.sendBufs.clear();
            }
        }else {
            while (!notReceived.contains(base)) {
                this.base++;
                if (mySerial != -1)
                    this.mySerial--;
            }
        }
    }

    public void resend() throws IOException {
        System.out.println("重新发送分组"+base);
        for(Map.Entry<Byte,Boolean> entry:this.timeUp.entrySet()){
            if(entry.getValue()) {
                this.timers.get(entry.getKey()).cancel();
                this.timers.remove(entry.getKey());
                send(this.sendBufs.get(entry.getKey()),entry.getKey());
            }
        }
    }

    private void send(DatagramPacket packet,byte number) throws IOException {
        packet.getData()[1]=serial;
        if(Math.random()>0.05) {
            this.socket.send(packet);
            System.out.println("发送分组："+packet.getData()[0]+" 期望分组："+(byte)(serial+1));
        }else{
            System.out.println("丢失发送分组"+number);
        }
        this.notReceived.add(number);
        Timer timer=new Timer(number +" packet timer");
        timer.schedule(new timerTask(this.timeUp,number),1000);
        this.timeUp.put(number,false);
        this.timers.put(number,timer);
    }
    public void update(byte num){
        notReceived.remove(num);
        timeUp.remove(num);
        timers.get(num).cancel();
        timers.remove(num);
        DatagramPacket tmp=this.sendBufs.get(num);
        sendBufs.remove(num);
        sendBufs.put((byte) (num+size),tmp);
    }

    public void delete(byte num){
        notReceived.remove(num);
        timeUp.remove(num);
        timers.get(num).cancel();
        timers.remove(num);
        sendBufs.remove(num);
    }

    public static void main(String[] args) throws SocketException {
        Server server =new Server(7749);
        server.run();
    }
}


class timerTask extends TimerTask {
    private Map<Byte,Boolean> timeUp;
    private byte num;
    public timerTask(Map<Byte,Boolean> timeUp,byte num){
        this.timeUp=timeUp;
        this.num=num;
    }
    @Override
    public void run() {
        synchronized (this) {
            System.out.println(num+"超时");
            this.timeUp.put(num, true);
        }
    }
}
