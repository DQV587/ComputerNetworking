package com.dq.web.lab1;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.http.io.HttpMessageParser;

import java.util.HashMap;
import java.util.Map;

@Data
public class ReqInfo {
    private String method;
    private String url;
    private String version;
    private String hostname;
    private int hostPort;
    private Map<String,String> headers;
    private String clientIP;
    private int clientPort;
    public ReqInfo(){
        this.headers=new HashMap<>();
        this.hostPort=80;
    }
    public void putHeaders(String key,String value){
        this.headers.put(key,value);
    }
}
