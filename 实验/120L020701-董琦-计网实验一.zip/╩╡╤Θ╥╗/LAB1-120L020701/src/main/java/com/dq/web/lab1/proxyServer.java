package com.dq.web.lab1;


import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class proxyServer {
    private proxyConfig proxyConfig;
    private int port;
    private ExecutorService threadPoll;
    private ServerSocket proxySocket;
    public proxyServer(int port){
        this.port=port;
        this.proxyConfig=new proxyConfig();
    }
    public void start(){
        try{
            this.threadPoll= Executors.newCachedThreadPool();
            this.proxySocket=new ServerSocket(port);
            System.out.println("代理服务器启动,监听"+port+"端口。");
            while(true){
                Socket in=proxySocket.accept();
                Thread t=new Thread(new requestHandler(in,this.proxyConfig));
                threadPoll.execute(t);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void setRedirect(Map<String,String> redirect){
        this.proxyConfig.setRedirect(redirect);
    }
    public void setForbiddenIP(Set<String> forbiddenIP){
        this.proxyConfig.setForbiddenIP(forbiddenIP);
    }
    public void setForbiddenHost(Set<String> forbiddenHost){
        this.proxyConfig.setForbiddenHost(forbiddenHost);
    }

    public static void main(String[] args){
        proxyServer proxyServer=new proxyServer(7890);
        //设置钓鱼
        Map<String,String> redirect=new HashMap<>();
        redirect.put("www.hit.edu.cn","jwts.hit.edu.cn");
        //设置禁止访问
        Set<String> forbiddenHost=new HashSet<>();
        forbiddenHost.add("www.baidu.com");
        Set<String> forbiddenIP=new HashSet<>();
        forbiddenIP.add("127.0.0.1");

        proxyServer.setRedirect(redirect);
        proxyServer.setForbiddenHost(forbiddenHost);
        proxyServer.setForbiddenIP(forbiddenIP);

        proxyServer.start();
    }

}
class requestHandler implements Runnable{

    private final Socket request;
    private Socket client;
    private ReqInfo reqInfo=new ReqInfo();
    private proxyConfig proxyConfig;
    private StringBuilder msg= new StringBuilder();
    private boolean legal=true;
    public requestHandler(Socket inPort,proxyConfig proxyConfig){
        request=inPort;
        this.proxyConfig=proxyConfig;
    }
    @Override
    public void run() {
        try(BufferedReader serverIn=new BufferedReader(
                new InputStreamReader(
                        request.getInputStream(), StandardCharsets.UTF_8));
            OutputStream serverOut= request.getOutputStream()
        ) {
            String line;
            while (!( line= serverIn.readLine()).equals("")){
                parser(line);
                msg.append(line).append("\r\n");
            }

            this.reqInfo.setClientIP(request.getInetAddress().toString().replace("/",""));
            this.reqInfo.setClientPort(request.getPort());

            processReq();

            if(legal)
                {String filepathPre="src\\cache\\";
                File folder=new File(filepathPre+reqInfo.getHostname());
                if(!folder.exists()&&!folder.isDirectory()){
                    if(folder.mkdirs())
                        System.out.println("创建文件夹成功:"+filepathPre+reqInfo.getHostname());
                }

                this.client=new Socket();
                this.client.connect(new InetSocketAddress(reqInfo.getHostname(), reqInfo.getHostPort()));

                if(client.isConnected() && !client.isClosed()){
//                    BufferedReader clientIn=new BufferedReader(new InputStreamReader(client.getInputStream()));
//                    PrintWriter clientOut=new PrintWriter(new OutputStreamWriter(client.getOutputStream()),true);
                    String cacheName="src\\cache\\"+reqInfo.getHostname()+"\\"+reqInfo.getUrl().hashCode()+".cache";
                    File cacheFile=new File(cacheName);
                    client.setSoTimeout(1000);

                    OutputStream clientOut=client.getOutputStream();
                    InputStream clientIn=client.getInputStream();
                    if(cacheFile.exists()){
                        System.out.println(reqInfo.getUrl()+"已缓存");

                        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z", Locale.ENGLISH);
                        df.setTimeZone(TimeZone.getTimeZone("GMT"));
                        msg.append("If-Modified-Since: ").append(df.format(cacheFile.lastModified())).append("\r\n");
                        msg.append("\r\n");

                        clientOut.write(msg.toString().getBytes());

                        FileReader fileReader=new FileReader(cacheFile);

                        int result;
                        try {
                            char response[]=new char[27];
                            int count=0;
                            while ((result = clientIn.read()) != -1&&count<27) {
                                response[count++]= (char) result;
                            }
                            if(String.valueOf(response).contains("304 Not Modified")){
                                System.out.println("缓存命中");

                                while((result=fileReader.read())!=-1)
                                {
                                    serverOut.write(result);
                                }
                            }
                            else{
                                System.out.println("缓存未命中");
                                {
                                    serverOut.write(String.valueOf(response).getBytes());
                                    while((result = clientIn.read()) != -1){
                                        serverOut.write(result);
                                    }
                                }
                            }
                        }catch (SocketTimeoutException e)
                        {
                            System.out.println(e);
                        }
                        fileReader.close();
                    }
                    else{
                        System.out.println(reqInfo.getUrl()+"未缓存");
                        cacheFile.createNewFile();
                        msg.append("\r\n");

                        clientOut.write(msg.toString().getBytes());

                        FileWriter fileWriter=new FileWriter(cacheFile,true);
                        int result;
                        try{
                            while((result=clientIn.read())!=-1){
                            serverOut.write(result);
                            fileWriter.write(result);
                            }
                        }catch (SocketTimeoutException e)
                        {
                            System.out.println(e);
                        }
                        fileWriter.close();
                    }
                }

                client.close();
                request.close();
            }
            System.out.println("任务结束");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    /*
        逐行处理请求字符串。
     */
    private void parser(String line){

        if(line.startsWith("GET")||line.startsWith("POST")){
            String[] requestLine=line.split("\\s+");
            if(requestLine.length==3){
                this.reqInfo.setMethod(requestLine[0]);
                this.reqInfo.setUrl(requestLine[1]);
                this.reqInfo.setVersion(requestLine[2]);
            }
        }
        else if(line.startsWith("Host")){
            String[] requestHeader=line.split(":");
            this.reqInfo.setHostname(requestHeader[1].trim());
            if(requestHeader.length==3){
                this.reqInfo.setHostPort(Integer.parseInt(requestHeader[2]));
            }
        }
        else {
            String[] requestHeader=line.split(":");
            this.reqInfo.putHeaders(requestHeader[0],requestHeader[1].trim());
        }
    }
    private void processReq(){
        if(this.proxyConfig.redirect!=null&&this.proxyConfig.redirect.keySet().contains(reqInfo.getHostname()))
        {
            String oldHost=this.reqInfo.getHostname();
            this.msg=new StringBuilder(this.msg.toString().replace(oldHost,this.proxyConfig.redirect.get(oldHost)));
            this.reqInfo.setHostname(this.proxyConfig.getRedirect().get(oldHost));
            this.reqInfo.setUrl(this.reqInfo.getUrl().replace(oldHost,this.proxyConfig.redirect.get(oldHost)));
        }
        if(this.proxyConfig.forbiddenHost.contains(this.reqInfo.getHostname()))
        {
            System.out.println("非法域名，禁止访问");
            legal=false;
        }
        if(this.proxyConfig.forbiddenIP.contains(this.reqInfo.getClientIP()))
        {
            System.out.println("非法IP，禁止访问");
            legal=false;
        }
    }
}