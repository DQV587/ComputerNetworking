package com.dq.web.lab1;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
import java.util.Set;
@Data
@NoArgsConstructor
public class proxyConfig {
    Map<String,String> redirect;
    Set<String> forbiddenIP;
    Set<String> forbiddenHost;
}
